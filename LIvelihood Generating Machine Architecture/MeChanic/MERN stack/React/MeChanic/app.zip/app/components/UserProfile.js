import React from 'react'
import { StyleSheet, TextInput, Text, View, Button } from 'react-native'
import { globalStyles } from '../assets/styles/global';

export default function UserProfile({ navigation }) {

    return (
        <View style={globalStyles.container}>

        </View>
    )
}